// SkillsWalk - Mock Database & Seed Data
// Knowledge is the new currency: 1 hr Teaching = +10 Credits | 1 hr Learning = -10 Credits

const INITIAL_SKILLS = [
  { id: 'sk-1', name: 'React & Next.js', category: 'Tech & Coding', icon: 'code', learners: 1420, mentors: 340, popular: true },
  { id: 'sk-2', name: 'Python & AI / ML', category: 'Tech & Coding', icon: 'terminal', learners: 1850, mentors: 410, popular: true },
  { id: 'sk-3', name: 'UI/UX & Figma', category: 'Design & Creative', icon: 'pen-tool', learners: 1640, mentors: 380, popular: true },
  { id: 'sk-4', name: 'Photography & Lighting', category: 'Creative & Media', icon: 'camera', learners: 980, mentors: 220, popular: true },
  { id: 'sk-5', name: 'Video Editing & Premiere', category: 'Creative & Media', icon: 'video', learners: 1120, mentors: 260, popular: true },
  { id: 'sk-6', name: 'Digital Marketing & SEO', category: 'Business & Growth', icon: 'trending-up', learners: 890, mentors: 190, popular: true },
  { id: 'sk-7', name: 'Generative AI Prompting', category: 'Tech & Coding', icon: 'cpu', learners: 1310, mentors: 290, popular: true },
  { id: 'sk-8', name: 'Motion Design (After Effects)', category: 'Design & Creative', icon: 'activity', learners: 760, mentors: 150, popular: false },
  { id: 'sk-9', name: 'Public Speaking & Pitching', category: 'Personal Growth', icon: 'mic', learners: 640, mentors: 130, popular: false },
  { id: 'sk-10', name: 'Mobile Dev (Flutter & React Native)', category: 'Tech & Coding', icon: 'smartphone', learners: 920, mentors: 210, popular: false }
];

const USERS = [
  {
    id: 'user-alex',
    name: 'Alex Morgan',
    role: 'Lead Product Designer & UI Architect',
    headline: 'Figma Design Systems Specialist | Eager to master React & Next.js',
    avatar: 'assets/avatar_alex.jpg',
    location: 'San Francisco, CA (PST)',
    rating: 4.96,
    reviewsCount: 38,
    credits: 50,
    hoursTaught: 18.5,
    hoursLearned: 12.0,
    bio: 'Passionate design system architect with 6+ years building scalable SaaS interfaces. Believer in reciprocal learning: I teach Figma component architectures, accessibility, and micro-interactions in exchange for hands-on modern frontend engineering guidance.',
    badges: [
      { id: 'b1', name: 'Top Mentor', icon: 'award', desc: 'Over 15+ highly rated teaching hours' },
      { id: 'b2', name: 'Skill Explorer', icon: 'compass', desc: 'Mastered 3+ complementary disciplines' },
      { id: 'b3', name: 'Verified Swapper', icon: 'check-circle', desc: 'Identity & portfolio verified' }
    ],
    teachSkills: [
      { name: 'UI/UX & Figma', level: 'Expert', rate: 10, hours: 14, tags: ['Figma', 'Design Systems', 'Micro-interactions', 'Prototyping'] },
      { name: 'User Research', level: 'Intermediate', rate: 10, hours: 4.5, tags: ['Usability Testing', 'Card Sorting'] }
    ],
    learnSkills: [
      { name: 'React & Next.js', priority: 'High', currentLevel: 'Beginner', target: 'Build interactive web apps from my Figma designs' },
      { name: 'Python & AI / ML', priority: 'Medium', currentLevel: 'Novice', target: 'Automate design token pipelines' }
    ],
    recentReviews: [
      { author: 'Sarah Chen', rating: 5, date: '2 days ago', text: 'Alex completely demystified Figma auto-layout and variable tokens for me! Super patient, hands-on, and gave me real design files to practice on.', skill: 'UI/UX & Figma' },
      { author: 'Marcus Vance', rating: 5, date: '1 week ago', text: 'Top tier mentor. In just 90 minutes, he audited my portfolio and showed me how to structure my design case studies. Worth every credit!', skill: 'UI/UX & Figma' }
    ]
  },
  {
    id: 'user-sarah',
    name: 'Sarah Chen',
    role: 'Staff Machine Learning Engineer',
    headline: 'Python & LLM Engineer @ AI Studio | Looking for UI/UX & Prototyping',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
    location: 'Seattle, WA (PST)',
    rating: 4.98,
    reviewsCount: 52,
    credits: 85,
    hoursTaught: 32.0,
    hoursLearned: 16.0,
    bio: 'ML researcher specializing in Python, PyTorch, and fine-tuning open-source LLMs. I love breaking down complex math and code into intuitive mental models. Looking to trade Python and GenAI mentorship for modern Figma UI design guidance for my side projects.',
    badges: [
      { id: 'b1', name: 'Top Mentor', icon: 'award', desc: 'Elite instructor with 50+ reviews' },
      { id: 'b4', name: 'AI Pioneer', icon: 'zap', desc: 'Specialized in cutting-edge AI frameworks' },
      { id: 'b5', name: 'Century Swapper', icon: 'shield', desc: 'Over 40 successful peer exchanges' }
    ],
    teachSkills: [
      { name: 'Python & AI / ML', level: 'Expert', rate: 10, hours: 22, tags: ['Python', 'PyTorch', 'LangChain', 'FastAPI'] },
      { name: 'Generative AI Prompting', level: 'Expert', rate: 10, hours: 10, tags: ['Prompt Engineering', 'RAG', 'Agentic Workflows'] }
    ],
    learnSkills: [
      { name: 'UI/UX & Figma', priority: 'High', currentLevel: 'Beginner', target: 'Design clean modern dashboards for my AI tools' },
      { name: 'Digital Marketing & SEO', priority: 'Medium', currentLevel: 'Novice', target: 'Grow audience for open-source AI repos' }
    ],
    recentReviews: [
      { author: 'Alex Morgan', rating: 5, date: '3 days ago', text: 'Sarah is an unbelievable teacher! She explained embeddings and vector search using visual diagrams that made everything click instantly.', skill: 'Python & AI / ML' },
      { author: 'Elena Rostova', rating: 5, date: '2 weeks ago', text: 'Helped me write my first Python web scraper to organize my photography archives. So kind and knowledgeable!', skill: 'Python & AI / ML' }
    ]
  },
  {
    id: 'user-marcus',
    name: 'Marcus Vance',
    role: 'Creative Director & Video Producer',
    headline: 'Cinematic Storytelling & DaVinci Resolve | Seeking React & Web Dev',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    location: 'Austin, TX (CST)',
    rating: 4.92,
    reviewsCount: 29,
    credits: 40,
    hoursTaught: 19.0,
    hoursLearned: 14.0,
    bio: 'Documentary filmmaker and YouTube creator with 8+ years producing commercial video. I teach video editing, color grading, audio mixing, and pacing. Want to learn frontend coding (React) to build interactive storytelling websites.',
    badges: [
      { id: 'b1', name: 'Top Mentor', icon: 'award', desc: 'Top-rated media mentor' },
      { id: 'b2', name: 'Skill Explorer', icon: 'compass', desc: 'Broad creative & technical skillset' }
    ],
    teachSkills: [
      { name: 'Video Editing & Premiere', level: 'Expert', rate: 10, hours: 15, tags: ['Premiere Pro', 'DaVinci Resolve', 'Color Grading', 'Sound Design'] },
      { name: 'Photography & Lighting', level: 'Advanced', rate: 10, hours: 4, tags: ['Studio Lighting', 'Composition', 'Framing'] }
    ],
    learnSkills: [
      { name: 'React & Next.js', priority: 'High', currentLevel: 'Beginner', target: 'Build portfolio and interactive web documentaries' },
      { name: 'Digital Marketing & SEO', priority: 'Medium', currentLevel: 'Intermediate', target: 'Optimize YouTube CTR and conversions' }
    ],
    recentReviews: [
      { author: 'David Kim', rating: 5, date: '5 days ago', text: 'Marcus taught me color grading curves in DaVinci. My tech demo videos went from amateur to looking like Netflix originals!', skill: 'Video Editing & Premiere' }
    ]
  },
  {
    id: 'user-priya',
    name: 'Priya Sharma',
    role: 'Growth Marketing Lead',
    headline: 'SEO & Performance Funnels | Learning Photography & Visual Branding',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    location: 'New York, NY (EST)',
    rating: 4.95,
    reviewsCount: 34,
    credits: 60,
    hoursTaught: 24.0,
    hoursLearned: 18.0,
    bio: 'Scale-up growth marketer specializing in organic SEO, content distribution, viral loops, and landing page conversion rate optimization. Seeking photography and lighting coaching to shoot my own brand assets and social reels.',
    badges: [
      { id: 'b1', name: 'Top Mentor', icon: 'award', desc: 'Marketing category star' },
      { id: 'b3', name: 'Verified Swapper', icon: 'check-circle', desc: 'Identity verified' }
    ],
    teachSkills: [
      { name: 'Digital Marketing & SEO', level: 'Expert', rate: 10, hours: 19, tags: ['SEO Audits', 'Keyword Strategy', 'Conversion Funnels', 'Copywriting'] },
      { name: 'Public Speaking & Pitching', level: 'Advanced', rate: 10, hours: 5, tags: ['Keynote Decks', 'Story Pitching'] }
    ],
    learnSkills: [
      { name: 'Photography & Lighting', priority: 'High', currentLevel: 'Beginner', target: 'Master DSLR manual mode & product photography' },
      { name: 'Video Editing & Premiere', priority: 'Medium', currentLevel: 'Novice', target: 'Edit short-form TikTok & Reels clips' }
    ],
    recentReviews: [
      { author: 'Carlos Mendez', rating: 5, date: '1 week ago', text: 'Priya audited my indie app landing page and doubled my conversion rate within 48 hours. Incredible marketing mind!', skill: 'Digital Marketing & SEO' }
    ]
  },
  {
    id: 'user-david',
    name: 'David Kim',
    role: 'Full Stack Engineer & Open Source Contributor',
    headline: 'Senior React & Node Engineer | Craving Video Editing & Motion Graphics',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80',
    location: 'Toronto, Canada (EST)',
    rating: 4.97,
    reviewsCount: 46,
    credits: 70,
    hoursTaught: 30.0,
    hoursLearned: 15.0,
    bio: 'Ex-startup CTO now building developer tools. I teach clean React architectures, Next.js App Router, state machines, and TypeScript. Looking to trade React mastery for video editing & motion graphics skills to produce polished software demo videos.',
    badges: [
      { id: 'b1', name: 'Top Mentor', icon: 'award', desc: 'Code community favorite' },
      { id: 'b5', name: 'Century Swapper', icon: 'shield', desc: '30+ completed swaps' }
    ],
    teachSkills: [
      { name: 'React & Next.js', level: 'Expert', rate: 10, hours: 25, tags: ['React 19', 'Next.js', 'TypeScript', 'State Management'] },
      { name: 'Mobile Dev (Flutter & React Native)', level: 'Advanced', rate: 10, hours: 5, tags: ['React Native', 'Expo'] }
    ],
    learnSkills: [
      { name: 'Video Editing & Premiere', priority: 'High', currentLevel: 'Beginner', target: 'Create slick product launch and showcase videos' },
      { name: 'Motion Design (After Effects)', priority: 'High', currentLevel: 'Novice', target: 'Animate UI interactions and logo stings' }
    ],
    recentReviews: [
      { author: 'Alex Morgan', rating: 5, date: 'Last week', text: 'David is a React wizard! He walked me through state lifecycles and custom hooks step by step. Code review was so thorough.', skill: 'React & Next.js' }
    ]
  },
  {
    id: 'user-elena',
    name: 'Elena Rostova',
    role: 'Commercial & Editorial Photographer',
    headline: 'Portrait & Studio Lighting Virtuoso | Learning Python & Web Automation',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80',
    location: 'Berlin, Germany (CET)',
    rating: 4.94,
    reviewsCount: 31,
    credits: 45,
    hoursTaught: 17.0,
    hoursLearned: 11.0,
    bio: 'Editorial portrait photographer published in international magazines. I teach lighting setups, focal lengths, Lightroom color grading, and directing models. In return, I want to learn Python to automate high-volume photo cataloging and cloud backups.',
    badges: [
      { id: 'b1', name: 'Top Mentor', icon: 'award', desc: 'Visual arts master' },
      { id: 'b2', name: 'Skill Explorer', icon: 'compass', desc: 'Cross-disciplinary learner' }
    ],
    teachSkills: [
      { name: 'Photography & Lighting', level: 'Expert', rate: 10, hours: 14, tags: ['Lightroom', 'Portraiture', 'Flash Photography', 'Composition'] },
      { name: 'Video Editing & Premiere', level: 'Intermediate', rate: 10, hours: 3, tags: ['Color Profiles', 'LUTs'] }
    ],
    learnSkills: [
      { name: 'Python & AI / ML', priority: 'High', currentLevel: 'Novice', target: 'Automate image tagging and batch image workflows' },
      { name: 'UI/UX & Figma', priority: 'Medium', currentLevel: 'Beginner', target: 'Redesign my portfolio site' }
    ],
    recentReviews: [
      { author: 'Priya Sharma', rating: 5, date: '4 days ago', text: 'Elena transformed my lighting in one session using just two cheap LED lamps and a white board! Phenomenal teacher.', skill: 'Photography & Lighting' }
    ]
  }
];

const INITIAL_TRANSACTIONS = [
  { id: 'tx-101', type: 'earn', title: 'Taught Figma Design Systems (1.5 hrs)', peer: 'Sarah Chen', amount: 15, date: 'Oct 04, 2026', time: '14:30', status: 'Completed', escrow: false },
  { id: 'tx-102', type: 'spend', title: 'Learned React Component Lifecycle (1.0 hr)', peer: 'David Kim', amount: 10, date: 'Oct 02, 2026', time: '18:00', status: 'Completed', escrow: false },
  { id: 'tx-103', type: 'earn', title: 'Taught UX Micro-Interactions (1.0 hr)', peer: 'Marcus Vance', amount: 10, date: 'Sep 29, 2026', time: '11:00', status: 'Completed', escrow: false },
  { id: 'tx-104', type: 'bonus', title: 'SkillsWalk Welcome Grant', peer: 'Platform Reward', amount: 20, date: 'Sep 20, 2026', time: '09:00', status: 'Granted', escrow: false },
  { id: 'tx-105', type: 'bonus', title: '5-Star Review Bonus (Top Mentor Streak)', peer: 'Community Reward', amount: 5, date: 'Sep 25, 2026', time: '16:15', status: 'Granted', escrow: false }
];

const INITIAL_SWAP_REQUESTS = [
  {
    id: 'req-1',
    fromUser: 'user-sarah',
    toUser: 'user-alex',
    offeredSkill: 'Python & AI / ML',
    requestedSkill: 'UI/UX & Figma',
    status: 'Pending',
    proposedDate: 'Tomorrow, Oct 07 • 6:30 PM PST',
    durationHours: 1.0,
    creditsCost: 10,
    message: 'Hey Alex! I saw your profile and AI matched us at 96%. I would love to teach you how to write custom Python scripts & LLM prompts in exchange for reviewing my AI analytics dashboard in Figma!',
    matchScore: 96
  },
  {
    id: 'req-2',
    fromUser: 'user-alex',
    toUser: 'user-david',
    offeredSkill: 'UI/UX & Figma',
    requestedSkill: 'React & Next.js',
    status: 'Accepted',
    proposedDate: 'Thursday, Oct 08 • 5:00 PM PST',
    durationHours: 1.5,
    creditsCost: 15,
    message: 'Hi David, looking forward to diving into Next.js App Router server actions and component state patterns!',
    matchScore: 94
  },
  {
    id: 'req-3',
    fromUser: 'user-marcus',
    toUser: 'user-alex',
    offeredSkill: 'Video Editing & Premiere',
    requestedSkill: 'UI/UX & Figma',
    status: 'Completed',
    proposedDate: 'Oct 01, 2026 • 2:00 PM PST',
    durationHours: 1.0,
    creditsCost: 10,
    message: 'Session completed. 10 credits transferred and 5-star review exchanged!',
    matchScore: 89
  }
];

const INITIAL_SESSIONS = [
  {
    id: 'ses-1',
    peerId: 'user-david',
    peerName: 'David Kim',
    peerRole: 'Full Stack Engineer',
    peerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80',
    skillToLearn: 'React & Next.js',
    topic: 'Next.js 15 Server Components & State Management',
    scheduledTime: 'Thursday, Oct 08 • 5:00 PM PST',
    relativeTime: 'In 2 days',
    duration: '60 minutes',
    creditsAmount: 10,
    status: 'Confirmed',
    meetingLink: 'https://meet.skillswalk.io/room/sw-alex-david-react'
  },
  {
    id: 'ses-2',
    peerId: 'user-sarah',
    peerName: 'Sarah Chen',
    peerRole: 'Staff ML Engineer',
    peerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
    skillToTeach: 'UI/UX & Figma',
    topic: 'Figma Auto-Layout & Design System Variables',
    scheduledTime: 'Saturday, Oct 10 • 11:00 AM PST',
    relativeTime: 'In 4 days',
    duration: '90 minutes',
    creditsAmount: 15,
    status: 'Confirmed',
    meetingLink: 'https://meet.skillswalk.io/room/sw-alex-sarah-figma'
  }
];

const LEARNING_PATHS = [
  {
    id: 'path-fullstack',
    title: 'Modern Full-Stack Web Architect',
    description: 'Bridge design, frontend components, and cloud APIs through guided peer mentoring.',
    category: 'Tech & Coding',
    icon: 'code',
    progress: 65,
    totalCreditsInvested: 30,
    milestones: [
      { id: 'm1', title: 'HTML5 Semantic Layouts & CSS Grid Mastery', completed: true, mentor: 'Alex Morgan (Self)' },
      { id: 'm2', title: 'Modern JavaScript ES6+ & Async/Await', completed: true, mentor: 'David Kim' },
      { id: 'm3', title: 'React 19 Components, State & Hooks', completed: true, mentor: 'David Kim' },
      { id: 'm4', title: 'Next.js App Router & Server Actions', completed: false, mentor: 'David Kim', activeNow: true },
      { id: 'm5', title: 'REST & GraphQL APIs Integration', completed: false, mentor: 'Sarah Chen' },
      { id: 'm6', title: 'Production Deployment & CWV Optimization', completed: false, mentor: 'Available Mentors' }
    ]
  },
  {
    id: 'path-ai-tools',
    title: 'Applied Generative AI & Automation',
    description: 'Harness LLMs, Python scrapers, and prompt engineering to supercharge creative workflows.',
    category: 'Tech & AI',
    icon: 'cpu',
    progress: 25,
    totalCreditsInvested: 10,
    milestones: [
      { id: 'ma1', title: 'Prompt Architecture & Context Engineering', completed: true, mentor: 'Sarah Chen' },
      { id: 'ma2', title: 'Python Fundamentals for Designers', completed: false, mentor: 'Sarah Chen', activeNow: true },
      { id: 'ma3', title: 'Building Local AI Agents with LangChain', completed: false, mentor: 'Sarah Chen' },
      { id: 'ma4', title: 'Automated Image & Asset Processing', completed: false, mentor: 'Elena Rostova' }
    ]
  },
  {
    id: 'path-visual-brand',
    title: 'Visual Storytelling & Commercial Video',
    description: 'Master lighting, cinematic camera work, and Premiere Pro / DaVinci editing.',
    category: 'Creative & Media',
    icon: 'video',
    progress: 10,
    totalCreditsInvested: 10,
    milestones: [
      { id: 'mv1', title: 'Three-Point Lighting & Studio Setup', completed: true, mentor: 'Marcus Vance' },
      { id: 'mv2', title: 'Video Pacing, Cuts & B-Roll Strategy', completed: false, mentor: 'Marcus Vance', activeNow: true },
      { id: 'mv3', title: 'Color Grading & Audio Mastering', completed: false, mentor: 'Marcus Vance' }
    ]
  }
];

const COMMUNITY_POSTS = [
  {
    id: 'post-1',
    author: 'Sarah Chen',
    authorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
    authorRole: 'ML Engineer',
    category: 'Swap Offer',
    tag: 'Python ⇄ Figma',
    title: 'Offering 1-on-1 Python & LLM prompt tuning in exchange for Figma dashboard audit!',
    content: 'Building an open-source analytics dashboard for AI developers. Need someone to review my Figma wireframes and show me how to organize tokens cleanly. In return, I can walk you through building your first custom AI agent or Python web automation script! Have 15 credits or direct swap ready.',
    likes: 24,
    liked: false,
    commentsCount: 9,
    timestamp: '2 hours ago',
    creditsReward: '10 cr/hr'
  },
  {
    id: 'post-2',
    author: 'Marcus Vance',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    authorRole: 'Video Producer',
    category: 'Tip & Guide',
    tag: 'Knowledge Economy',
    title: 'How I learned React in 3 weeks without paying a single dollar in tuition',
    content: 'Instead of buying a $500 bootcamp, I used 30 SkillsWalk credits earned by teaching basic Premiere video editing to junior creators. In exchange, two senior frontend devs paired with me on code reviews twice a week. Direct barter of human experience beats pre-recorded video tutorials every single time!',
    likes: 67,
    liked: true,
    commentsCount: 18,
    timestamp: '5 hours ago',
    creditsReward: null
  },
  {
    id: 'post-3',
    author: 'Priya Sharma',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    authorRole: 'Growth Marketer',
    category: 'Help Wanted',
    tag: 'Photography ⇄ SEO',
    title: 'Looking for a portrait photographer in NYC/remote to coach on lighting for founders',
    content: 'I run webinars and video podcasts and my webcam lighting looks flat. Willing to trade in-depth SEO strategy audit (I typically charge $200/hr consulting) or 20 SkillsWalk credits for 2 hours of lighting & camera setup coaching.',
    likes: 31,
    liked: false,
    commentsCount: 14,
    timestamp: 'Yesterday',
    creditsReward: '20 credits'
  }
];

const LEADERBOARD_USERS = [
  { rank: 1, name: 'Sarah Chen', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80', primarySkill: 'Python & AI / ML', hoursTaught: 32.0, creditsEarned: 320, badge: 'Grandmaster Mentor', swaps: 48 },
  { rank: 2, name: 'David Kim', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80', primarySkill: 'React & Next.js', hoursTaught: 30.0, creditsEarned: 300, badge: 'Tech Luminary', swaps: 42 },
  { rank: 3, name: 'Priya Sharma', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80', primarySkill: 'Digital Marketing & SEO', hoursTaught: 24.0, creditsEarned: 240, badge: 'Growth Guru', swaps: 35 },
  { rank: 4, name: 'Alex Morgan', avatar: 'assets/avatar_alex.jpg', primarySkill: 'UI/UX & Figma', hoursTaught: 18.5, creditsEarned: 185, badge: 'Design Pioneer', swaps: 28 },
  { rank: 5, name: 'Marcus Vance', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80', primarySkill: 'Video Editing & Premiere', hoursTaught: 19.0, creditsEarned: 190, badge: 'Visual Storyteller', swaps: 26 },
  { rank: 6, name: 'Elena Rostova', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80', primarySkill: 'Photography & Lighting', hoursTaught: 17.0, creditsEarned: 170, badge: 'Master of Light', swaps: 23 }
];

const CHAT_THREADS = [
  {
    userId: 'user-sarah',
    userName: 'Sarah Chen',
    userRole: 'Staff ML Engineer',
    userAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
    online: true,
    lastActive: 'Active now',
    messages: [
      { sender: 'them', text: 'Hi Alex! I saw your Figma design system tutorials on your profile. The variable token structure looks incredible.', time: '10:14 AM' },
      { sender: 'me', text: 'Thanks Sarah! Appreciate that. I checked out your Python ML repo too—really impressed with your prompt engineering framework.', time: '10:16 AM' },
      { sender: 'them', text: 'SkillsWalk matched us at 96% compatibility! I’d love to do a 1-hour swap this week: I teach you Python automation basics, and you audit my analytics dashboard wireframe?', time: '10:18 AM' },
      { sender: 'swap_card', swapId: 'req-1', status: 'Pending', offeredSkill: 'Python & AI / ML', requestedSkill: 'UI/UX & Figma', duration: '1.0 hr (10 Credits)', time: '10:19 AM' }
    ]
  },
  {
    userId: 'user-david',
    userName: 'David Kim',
    userRole: 'Full Stack React Engineer',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80',
    online: true,
    lastActive: '5m ago',
    messages: [
      { sender: 'them', text: 'Hey Alex! Our session for Thursday at 5:00 PM PST is confirmed.', time: 'Yesterday' },
      { sender: 'me', text: 'Awesome David! I have my Figma sandbox ready, and I prepared a few questions on Next.js 15 Server Actions.', time: 'Yesterday' },
      { sender: 'them', text: 'Perfect. We’ll jump straight into code and wire up your Figma components to live React state. See you then!', time: 'Yesterday' }
    ]
  },
  {
    userId: 'user-marcus',
    userName: 'Marcus Vance',
    userRole: 'Video Producer',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    online: false,
    lastActive: '2h ago',
    messages: [
      { sender: 'them', text: 'Thanks again for the UX review last week! The portfolio conversion has already improved.', time: 'Oct 02' },
      { sender: 'me', text: 'So glad to hear that Marcus! Whenever you want to run another session on DaVinci color grading, let me know.', time: 'Oct 02' },
      { sender: 'them', text: 'Will do! Let’s book another one next week.', time: 'Oct 02' }
    ]
  }
];

const NOTIFICATIONS = [
  { id: 'notif-1', unread: true, title: '96% AI Match Found!', body: 'Sarah Chen wants to learn UI/UX and teaches Python & AI. Perfect complementary swap!', time: '10 min ago', icon: 'zap', link: 'ai-matching' },
  { id: 'notif-2', unread: true, title: 'Swap Proposal Received', body: 'Sarah Chen sent you a 1-hour swap request: Python for Figma.', time: '25 min ago', icon: 'repeat', link: 'dashboard' },
  { id: 'notif-3', unread: false, title: 'Session Confirmed', body: 'David Kim confirmed your React & Next.js session for Thursday, Oct 08 at 5:00 PM.', time: '1 day ago', icon: 'calendar', link: 'dashboard' },
  { id: 'notif-4', unread: false, title: '+15 Credits Awarded', body: 'Sarah Chen left you a 5-star review! 15 credits transferred to your wallet.', time: '2 days ago', icon: 'credit-card', link: 'wallet' },
  { id: 'notif-5', unread: false, title: 'Badge Unlocked: Top Mentor', body: 'Congratulations! You reached 15+ highly rated hours of peer teaching.', time: '3 days ago', icon: 'award', link: 'profile' }
];
