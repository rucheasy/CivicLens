// SkillsWalk - Application Logic & Core Controllers
// "Knowledge is the New Currency"

class SkillsWalkApp {
  constructor() {
    // Current logged-in user persona (Default: Alex Morgan, UI/UX Designer)
    this.currentUser = JSON.parse(JSON.stringify(USERS[0]));
    this.users = JSON.parse(JSON.stringify(USERS));
    this.skills = JSON.parse(JSON.stringify(INITIAL_SKILLS));
    this.transactions = JSON.parse(JSON.stringify(INITIAL_TRANSACTIONS));
    this.swapRequests = JSON.parse(JSON.stringify(INITIAL_SWAP_REQUESTS));
    this.sessions = JSON.parse(JSON.stringify(INITIAL_SESSIONS));
    this.communityPosts = JSON.parse(JSON.stringify(COMMUNITY_POSTS));
    this.chatThreads = JSON.parse(JSON.stringify(CHAT_THREADS));
    this.notifications = JSON.parse(JSON.stringify(NOTIFICATIONS));

    // UI state
    this.currentView = 'home';
    this.activeChatUserId = 'user-sarah';
    this.currentCategory = 'All';
    this.searchQuery = '';
    this.sortBy = 'rating';
    this.minMatchScore = 90;
    this.activeSwapPeer = null;
    this.activeSessionData = null;
    this.selectedStarRating = 5;
    this.txFilter = 'all';
    this.sessionTimerInterval = null;

    this.init();
  }

  init() {
    this.setupTheme();
    this.renderAll();
    this.setupHashRouting();
    this.initIcons();
  }

  initIcons() {
    if (window.feather) {
      window.feather.replace();
    }
  }

  // =========================================================================
  // ROUTING & NAVIGATION
  // =========================================================================
  navigateTo(viewName) {
    this.currentView = viewName;
    window.location.hash = viewName;

    // Hide all views
    document.querySelectorAll('.app-view-container').forEach(el => {
      el.classList.remove('active');
    });

    // Show target view
    const target = document.getElementById(`view-${viewName}`);
    if (target) {
      target.classList.add('active');
    }

    // Update nav links
    document.querySelectorAll('.nav-item-btn').forEach(btn => {
      if (btn.getAttribute('data-view') === viewName) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Close notifications or drawers if open
    const notifDropdown = document.getElementById('notif-dropdown');
    if (notifDropdown) notifDropdown.style.display = 'none';
    const mobileDrawer = document.getElementById('mobile-drawer');
    if (mobileDrawer) mobileDrawer.style.display = 'none';

    window.scrollTo({ top: 0, behavior: 'smooth' });

    // View specific refreshes
    if (viewName === 'ai-matching') this.renderAIMatches();
    if (viewName === 'dashboard') this.renderDashboard();
    if (viewName === 'wallet') this.renderWallet();
    if (viewName === 'skills') this.renderSkillsCatalog();
    if (viewName === 'chat') this.renderChat();
    if (viewName === 'community') this.renderCommunity();
    if (viewName === 'leaderboard') this.renderLeaderboard();
    if (viewName === 'paths') this.renderLearningPaths();

    this.initIcons();
  }

  setupHashRouting() {
    const hash = window.location.hash.replace('#', '');
    if (hash && document.getElementById(`view-${hash}`)) {
      this.navigateTo(hash);
    } else {
      this.navigateTo('home');
    }

    window.addEventListener('hashchange', () => {
      const newHash = window.location.hash.replace('#', '');
      if (newHash && newHash !== this.currentView && document.getElementById(`view-${newHash}`)) {
        this.navigateTo(newHash);
      }
    });
  }

  // =========================================================================
  // THEME TOGGLE
  // =========================================================================
  setupTheme() {
    const saved = localStorage.getItem('skillswalk-theme') || 'dark';
    if (saved === 'light') {
      document.body.classList.add('light-theme');
    }
    this.updateThemeIcon();
  }

  toggleTheme() {
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('skillswalk-theme', isLight ? 'light' : 'dark');
    this.updateThemeIcon();
    this.showToast(isLight ? 'Light theme activated' : 'Dark theme activated', 'Theme Updated');
  }

  updateThemeIcon() {
    const iconEl = document.getElementById('theme-icon');
    if (iconEl) {
      const isLight = document.body.classList.contains('light-theme');
      iconEl.setAttribute('data-feather', isLight ? 'sun' : 'moon');
      this.initIcons();
    }
  }

  // =========================================================================
  // RENDER MASTER
  // =========================================================================
  renderAll() {
    this.updateNavProfile();
    this.renderFeaturedHomeSkills();
    this.renderDashboard();
    this.renderAIMatches();
    this.renderSkillsCatalog();
    this.renderWallet();
    this.renderChat();
    this.renderCommunity();
    this.renderLeaderboard();
    this.renderLearningPaths();
    this.renderNotifications();
  }

  updateNavProfile() {
    const creditEl = document.getElementById('nav-credit-balance');
    const avatarEl = document.getElementById('nav-user-avatar');
    const nameEl = document.getElementById('nav-user-name');
    const roleEl = document.getElementById('nav-user-role');

    if (creditEl) creditEl.textContent = this.currentUser.credits;
    if (avatarEl) avatarEl.src = this.currentUser.avatar;
    if (nameEl) nameEl.textContent = this.currentUser.name;
    if (roleEl) roleEl.textContent = this.currentUser.role.split('&')[0];
  }

  // =========================================================================
  // HOME PAGE: FEATURED SKILLS
  // =========================================================================
  renderFeaturedHomeSkills() {
    const container = document.getElementById('home-featured-skills-grid');
    if (!container) return;

    const featured = this.skills.slice(0, 6);
    container.innerHTML = featured.map(sk => {
      // Find top mentor for this skill
      const mentor = this.users.find(u => u.teachSkills.some(ts => ts.name.toLowerCase().includes(sk.name.toLowerCase().split('&')[0].trim()))) || this.users[1];
      
      return `
        <div class="mentor-skill-card glass-card">
          <div class="card-header-mentor">
            <div class="mentor-info-cluster">
              <img src="${mentor.avatar}" alt="${mentor.name}" class="mentor-thumb" onclick="app.openProfileModal('${mentor.id}')" style="cursor: pointer;">
              <div>
                <div class="mentor-name-title">${mentor.name}</div>
                <div style="font-size: 0.78rem; color: var(--text-muted);">${mentor.role.split('&')[0]}</div>
              </div>
            </div>
            <div class="mentor-rating-chip">
              ★ ${mentor.rating} (${mentor.reviewsCount})
            </div>
          </div>

          <div>
            <span class="badge badge-primary" style="margin-bottom: 0.5rem;">${sk.category}</span>
            <h3 class="skill-card-main-title">${sk.name}</h3>
            <p style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.5; margin-top: 0.4rem;">
              Learn directly through hands-on barter or spend earned knowledge credits.
            </p>
          </div>

          <div class="credit-rate-bar">
            <div>
              <div style="font-size: 0.72rem; color: var(--text-subtle); text-transform: uppercase;">Barter Rate</div>
              <div class="credit-rate-val">
                <img src="assets/coin_token.jpg" alt="Coin" style="width: 1.1rem; height: 1.1rem; border-radius: 50%;">
                10 CR / hr
              </div>
            </div>
            <button class="btn btn-primary btn-sm" onclick="app.openSwapModal('${mentor.id}', '${sk.name}')">
              <i data-feather="repeat"></i> Request Swap
            </button>
          </div>
        </div>
      `;
    }).join('');

    this.initIcons();
  }

  // =========================================================================
  // AI MATCHMAKER ENGINE
  // =========================================================================
  calculateMatchDetails(otherUser) {
    // Current user's skills
    const myTeach = this.currentUser.teachSkills.map(s => s.name);
    const myLearn = this.currentUser.learnSkills.map(s => s.name);
    const theirTeach = otherUser.teachSkills.map(s => s.name);
    const theirLearn = otherUser.learnSkills.map(s => s.name);

    // Mutual Complementarity Check
    // Can I teach them something they want?
    const iCanTeachThem = myTeach.filter(ms => theirLearn.some(tl => tl.toLowerCase().includes(ms.toLowerCase()) || ms.toLowerCase().includes(tl.toLowerCase())));
    // Can they teach me something I want?
    const theyCanTeachMe = theirTeach.filter(ts => myLearn.some(ml => ml.toLowerCase().includes(ts.toLowerCase()) || ts.toLowerCase().includes(ml.toLowerCase())));

    let score = 75;
    let rationale = '';

    if (iCanTeachThem.length > 0 && theyCanTeachMe.length > 0) {
      score = 96;
      rationale = `Perfect bilateral barter! You teach ${iCanTeachThem[0]} which ${otherUser.name.split(' ')[0]} actively wants. In return, ${otherUser.name.split(' ')[0]} is an expert in ${theyCanTeachMe[0]}, which is your top learning priority. Mutual schedules and timezone compatibility are optimal!`;
    } else if (theyCanTeachMe.length > 0) {
      score = 92;
      rationale = `${otherUser.name.split(' ')[0]} teaches ${theyCanTeachMe[0]} at master level, matching your learning roadmap. You can spend 10 credits from your wallet or propose an open trade.`;
    } else if (iCanTeachThem.length > 0) {
      score = 88;
      rationale = `${otherUser.name.split(' ')[0]} urgently needs guidance in ${iCanTeachThem[0]}. By teaching them, you can earn +10 to +20 Credits for your learning goals!`;
    } else {
      score = 82;
      rationale = `High collaborative overlap across complementary creative and tech disciplines. Verified mentor with a ${otherUser.rating}★ rating.`;
    }

    return {
      score,
      rationale,
      youTeach: iCanTeachThem.length > 0 ? iCanTeachThem[0] : myTeach[0],
      theyTeach: theyCanTeachMe.length > 0 ? theyCanTeachMe[0] : theirTeach[0]
    };
  }

  renderAIMatches() {
    const container = document.getElementById('ai-matches-cards-grid');
    if (!container) return;

    // Filter peers (excluding self)
    const peers = this.users.filter(u => u.id !== this.currentUser.id);
    
    // Calculate match metrics
    const matchResults = peers.map(peer => {
      const details = this.calculateMatchDetails(peer);
      return {
        peer,
        ...details
      };
    }).sort((a, b) => b.score - a.score);

    // Apply min score filter
    const filtered = matchResults.filter(m => m.score >= this.minMatchScore);

    const countLabel = document.getElementById('match-results-count');
    if (countLabel) {
      countLabel.textContent = `${filtered.length} Highly Compatible Swappers (${this.minMatchScore}%+ Threshold)`;
    }

    container.innerHTML = filtered.map(m => {
      const u = m.peer;
      return `
        <div class="match-card glass-card">
          <div class="match-card-top">
            <div class="match-user-meta">
              <img src="${u.avatar}" alt="${u.name}" class="match-user-avatar" onclick="app.openProfileModal('${u.id}')" style="cursor: pointer;">
              <div>
                <h3 style="font-size: 1.25rem; font-weight: 800; cursor: pointer;" onclick="app.openProfileModal('${u.id}')">${u.name}</h3>
                <div style="font-size: 0.82rem; color: var(--text-muted);">${u.role}</div>
                <div style="font-size: 0.78rem; color: var(--text-subtle); margin-top: 0.2rem;">📍 ${u.location}</div>
              </div>
            </div>

            <div class="match-score-badge" title="AI Reciprocal Compatibility Score">
              <span class="score-num">${m.score}%</span>
              <span class="score-lbl">MATCH</span>
            </div>
          </div>

          <!-- Complementary Barter Matrix -->
          <div class="barter-matrix-box">
            <div class="matrix-col">
              <span class="matrix-label">You Give (Teach)</span>
              <span class="matrix-skill text-gradient">${m.youTeach}</span>
            </div>

            <div class="matrix-arrow">
              <i data-feather="repeat" style="width: 1.5rem; height: 1.5rem;"></i>
            </div>

            <div class="matrix-col" style="text-align: right;">
              <span class="matrix-label">You Get (Learn)</span>
              <span class="matrix-skill text-cyan">${m.theyTeach}</span>
            </div>
          </div>

          <!-- AI Match Explanation -->
          <div class="ai-rationale-box">
            <div class="ai-rationale-title">
              <i data-feather="zap" style="width: 0.95rem; height: 0.95rem;"></i> Why This Is A Great Match:
            </div>
            <div>${m.rationale}</div>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="font-size: 0.82rem; color: var(--text-muted);">
              ★ <strong>${u.rating}</strong> (${u.reviewsCount} reviews) • <span class="text-gold">10 CR / hr</span>
            </div>
            <span class="badge badge-gold"><i data-feather="award"></i> ${u.badges[0].name}</span>
          </div>

          <div class="match-actions-row">
            <button class="btn btn-primary" style="flex: 1;" onclick="app.openSwapModal('${u.id}', '${m.theyTeach}')">
              <i data-feather="repeat"></i> Propose Skill Swap
            </button>
            <button class="btn btn-secondary" onclick="app.openChatWithUser('${u.id}')" title="Message ${u.name}">
              <i data-feather="message-square"></i>
            </button>
            <button class="btn btn-secondary" onclick="app.openProfileModal('${u.id}')" title="View Full Profile">
              <i data-feather="user"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');

    this.initIcons();
  }

  filterMatchesByScore(val) {
    this.minMatchScore = parseInt(val, 10);
    this.renderAIMatches();
  }

  refreshAIMatches() {
    this.showToast('AI Synergy Matrix recalculated with latest platform activity.', 'Matches Refreshed');
    this.renderAIMatches();
  }

  // =========================================================================
  // SKILL DISCOVERY CATALOG
  // =========================================================================
  renderSkillsCatalog() {
    const container = document.getElementById('skills-catalog-grid');
    if (!container) return;

    // Filter peers excluding current user
    let list = [];
    this.users.filter(u => u.id !== this.currentUser.id).forEach(user => {
      user.teachSkills.forEach(ts => {
        list.push({
          user,
          skill: ts
        });
      });
    });

    // Filter by Category
    if (this.currentCategory !== 'All') {
      list = list.filter(item => {
        const cat = this.getSkillCategory(item.skill.name);
        return cat === this.currentCategory;
      });
    }

    // Filter by Search Query
    if (this.searchQuery.trim() !== '') {
      const q = this.searchQuery.toLowerCase();
      list = list.filter(item => 
        item.skill.name.toLowerCase().includes(q) ||
        item.user.name.toLowerCase().includes(q) ||
        item.skill.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    // Sort
    if (this.sortBy === 'rating') {
      list.sort((a, b) => b.user.rating - a.user.rating);
    } else if (this.sortBy === 'hours') {
      list.sort((a, b) => b.skill.hours - a.skill.hours);
    } else if (this.sortBy === 'name') {
      list.sort((a, b) => a.skill.name.localeCompare(b.skill.name));
    }

    const countLabel = document.getElementById('skills-count-label');
    if (countLabel) {
      countLabel.textContent = `Showing ${list.length} mentors available across ${this.currentCategory}`;
    }

    if (list.length === 0) {
      container.innerHTML = `
        <div class="glass-card" style="grid-column: 1 / -1; padding: 3rem; text-align: center;">
          <i data-feather="search" style="width: 3rem; height: 3rem; color: var(--text-subtle); margin-bottom: 1rem;"></i>
          <h3>No matching mentors found</h3>
          <p style="color: var(--text-muted); margin-top: 0.5rem;">Try modifying your keyword search or select "All Categories".</p>
        </div>
      `;
      this.initIcons();
      return;
    }

    container.innerHTML = list.map(item => {
      const u = item.user;
      const sk = item.skill;
      const cat = this.getSkillCategory(sk.name);

      return `
        <div class="mentor-skill-card glass-card">
          <div class="card-header-mentor">
            <div class="mentor-info-cluster">
              <img src="${u.avatar}" alt="${u.name}" class="mentor-thumb" onclick="app.openProfileModal('${u.id}')" style="cursor: pointer;">
              <div>
                <div class="mentor-name-title" onclick="app.openProfileModal('${u.id}')" style="cursor: pointer;">${u.name}</div>
                <div style="font-size: 0.78rem; color: var(--text-muted);">${u.role.split('&')[0]}</div>
              </div>
            </div>
            <div class="mentor-rating-chip">
              ★ ${u.rating} (${u.reviewsCount})
            </div>
          </div>

          <div>
            <div style="display: flex; gap: 0.4rem; align-items: center; margin-bottom: 0.5rem;">
              <span class="badge badge-primary">${cat}</span>
              <span class="badge badge-cyan">${sk.level}</span>
            </div>
            <h3 class="skill-card-main-title">${sk.name}</h3>
            
            <div class="skill-tags-cloud" style="margin-top: 0.75rem;">
              ${sk.tags.map(t => `<span class="tag-badge">#${t}</span>`).join('')}
            </div>
          </div>

          <div style="font-size: 0.85rem; color: var(--text-muted); background: rgba(10, 11, 20, 0.4); padding: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-glass);">
            <div style="font-size: 0.72rem; text-transform: uppercase; color: var(--text-subtle); font-weight: 700;">Wants in return:</div>
            <div style="color: var(--text-main); font-weight: 600;">${u.learnSkills.map(ls => ls.name).join(', ')}</div>
          </div>

          <div class="credit-rate-bar">
            <div>
              <div style="font-size: 0.72rem; color: var(--text-subtle); text-transform: uppercase;">Knowledge Rate</div>
              <div class="credit-rate-val">
                <img src="assets/coin_token.jpg" alt="Coin" style="width: 1.1rem; height: 1.1rem; border-radius: 50%;">
                ${sk.rate} CR / hr
              </div>
            </div>
            <div style="display: flex; gap: 0.5rem;">
              <button class="btn btn-secondary btn-sm" onclick="app.openProfileModal('${u.id}')" title="Profile">
                <i data-feather="user"></i>
              </button>
              <button class="btn btn-primary btn-sm" onclick="app.openSwapModal('${u.id}', '${sk.name}')">
                <i data-feather="repeat"></i> Request Swap
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    this.initIcons();
  }

  getSkillCategory(skillName) {
    const s = this.skills.find(sk => sk.name.toLowerCase() === skillName.toLowerCase());
    return s ? s.category : 'Tech & Coding';
  }

  handleSkillSearch(query) {
    this.searchQuery = query;
    this.renderSkillsCatalog();
  }

  filterCategory(cat) {
    this.currentCategory = cat;
    document.querySelectorAll('.category-pill').forEach(pill => {
      if (pill.textContent.trim() === cat || (cat === 'All' && pill.textContent.trim() === 'All Categories')) {
        pill.classList.add('active');
      } else {
        pill.classList.remove('active');
      }
    });
    this.renderSkillsCatalog();
  }

  sortSkills(by) {
    this.sortBy = by;
    this.renderSkillsCatalog();
  }

  // =========================================================================
  // DASHBOARD CONTROLLERS
  // =========================================================================
  renderDashboard() {
    // Welcome card stats
    const greetName = document.getElementById('dash-greeting-name');
    const creditsSum = document.getElementById('dash-credits-summary');
    const walletBal = document.getElementById('dash-wallet-balance');
    const avatarMain = document.getElementById('dash-avatar-main');

    if (greetName) greetName.textContent = `Welcome back, ${this.currentUser.name.split(' ')[0]}!`;
    if (creditsSum) creditsSum.textContent = `${this.currentUser.credits} Credits`;
    if (walletBal) walletBal.textContent = `${this.currentUser.credits} CR`;
    if (avatarMain) avatarMain.src = this.currentUser.avatar;

    // Requests Container
    const reqContainer = document.getElementById('dash-requests-container');
    const pendingCount = document.getElementById('dash-pending-count');
    
    if (reqContainer) {
      const activeReqs = this.swapRequests;
      if (pendingCount) {
        const pendingNum = activeReqs.filter(r => r.status === 'Pending').length;
        pendingCount.textContent = `${pendingNum} Action Required`;
      }

      reqContainer.innerHTML = activeReqs.map(req => {
        const isIncoming = req.toUser === this.currentUser.id;
        const otherUserId = isIncoming ? req.fromUser : req.toUser;
        const otherUser = this.users.find(u => u.id === otherUserId) || this.users[1];

        return `
          <div class="request-item-card glass-card">
            <div class="request-item-header">
              <div class="request-user-info">
                <img src="${otherUser.avatar}" alt="${otherUser.name}" class="req-avatar" onclick="app.openProfileModal('${otherUser.id}')" style="cursor: pointer;">
                <div>
                  <div class="req-name">${isIncoming ? `Proposal from ${otherUser.name}` : `Sent to ${otherUser.name}`}</div>
                  <div class="req-date-meta">📅 ${req.proposedDate} • <strong>${req.durationHours} hr (${req.creditsCost} CR)</strong></div>
                </div>
              </div>
              <span class="badge ${req.status === 'Accepted' ? 'badge-success' : req.status === 'Pending' ? 'badge-cyan' : 'badge-gold'}">
                ${req.status}
              </span>
            </div>

            <div class="barter-matrix-box" style="padding: 0.65rem 1rem;">
              <div class="matrix-col">
                <span class="matrix-label">Offered Skill</span>
                <span style="font-weight: 700; font-size: 0.88rem;">${req.offeredSkill}</span>
              </div>
              <div class="matrix-arrow"><i data-feather="arrow-right"></i></div>
              <div class="matrix-col" style="text-align: right;">
                <span class="matrix-label">Requested Skill</span>
                <span style="font-weight: 700; font-size: 0.88rem;">${req.requestedSkill}</span>
              </div>
            </div>

            <div class="req-body-msg">
              "${req.message}"
            </div>

            <div class="req-actions-bar">
              <span style="font-size: 0.8rem; color: var(--text-subtle);">
                AI Synergy: <strong class="text-cyan">${req.matchScore}% Match</strong>
              </span>

              <div style="display: flex; gap: 0.5rem;">
                ${req.status === 'Pending' && isIncoming ? `
                  <button class="btn btn-secondary btn-sm" onclick="app.declineSwap('${req.id}')">Decline</button>
                  <button class="btn btn-primary btn-sm" onclick="app.acceptSwap('${req.id}')">
                    <i data-feather="check"></i> Accept Swap
                  </button>
                ` : `
                  <button class="btn btn-secondary btn-sm" onclick="app.openChatWithUser('${otherUser.id}')">
                    <i data-feather="message-square"></i> Chat
                  </button>
                  ${req.status === 'Accepted' ? `
                    <button class="btn btn-primary btn-sm" onclick="app.launchInteractiveSessionRoom('${req.requestedSkill}', '${otherUser.name}')">
                      <i data-feather="video"></i> Enter Room
                    </button>
                  ` : ''}
                `}
              </div>
            </div>
          </div>
        `;
      }).join('');
    }

    // Sessions Container
    const sesContainer = document.getElementById('dash-sessions-container');
    if (sesContainer) {
      sesContainer.innerHTML = this.sessions.map(ses => {
        return `
          <div class="session-card glass-card">
            <div class="session-header-row">
              <div style="display: flex; align-items: center; gap: 0.75rem;">
                <img src="${ses.peerAvatar}" alt="${ses.peerName}" style="width: 2.6rem; height: 2.6rem; border-radius: 50%; object-fit: cover;">
                <div>
                  <div style="font-weight: 700; font-size: 0.95rem;">${ses.topic}</div>
                  <div style="font-size: 0.8rem; color: var(--text-muted);">With ${ses.peerName} (${ses.peerRole})</div>
                </div>
              </div>
              <div class="session-time-pill">
                <i data-feather="clock" style="width: 0.95rem; height: 0.95rem;"></i> ${ses.relativeTime}
              </div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 0.5rem; border-top: 1px solid var(--border-light);">
              <span style="font-size: 0.8rem; color: var(--text-subtle);">
                📅 ${ses.scheduledTime} (${ses.duration})
              </span>
              <button class="btn btn-primary btn-sm" onclick="app.launchInteractiveSessionRoom('${ses.topic}', '${ses.peerName}')">
                <i data-feather="video"></i> Join Live Session
              </button>
            </div>
          </div>
        `;
      }).join('');
    }

    // Quick AI matches for Dashboard sidebar
    const quickMatchesContainer = document.getElementById('dash-quick-matches');
    if (quickMatchesContainer) {
      const peers = this.users.filter(u => u.id !== this.currentUser.id).slice(0, 2);
      quickMatchesContainer.innerHTML = peers.map(p => {
        const match = this.calculateMatchDetails(p);
        return `
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; padding: 0.75rem; background: rgba(10, 11, 20, 0.4); border-radius: var(--radius-sm); border: 1px solid var(--border-glass);">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <img src="${p.avatar}" alt="${p.name}" style="width: 2.4rem; height: 2.4rem; border-radius: 50%; object-fit: cover;">
              <div>
                <div style="font-weight: 700; font-size: 0.88rem;">${p.name}</div>
                <div style="font-size: 0.75rem; color: #22d3ee; font-weight: 700;">${match.score}% Compatibility</div>
              </div>
            </div>
            <button class="btn btn-secondary btn-sm" onclick="app.openSwapModal('${p.id}', '${match.theyTeach}')">
              Swap
            </button>
          </div>
        `;
      }).join('');
    }

    this.initIcons();
  }

  // =========================================================================
  // WALLET & TRANSACTION PASSBOOK
  // =========================================================================
  renderWallet() {
    const hugeBal = document.getElementById('wallet-huge-balance');
    if (hugeBal) hugeBal.textContent = this.currentUser.credits;

    const tbody = document.getElementById('transactions-table-body');
    if (!tbody) return;

    let filtered = this.transactions;
    if (this.txFilter !== 'all') {
      filtered = filtered.filter(tx => tx.type === this.txFilter);
    }

    tbody.innerHTML = filtered.map(tx => {
      const isPlus = tx.type === 'earn' || tx.type === 'bonus';
      return `
        <tr>
          <td>
            <div style="font-weight: 700;">${tx.title}</div>
            <div style="font-size: 0.75rem; color: var(--text-subtle);">Ref ID: ${tx.id}</div>
          </td>
          <td>${tx.peer}</td>
          <td>${tx.date} • ${tx.time}</td>
          <td>
            <span class="badge ${tx.status === 'Completed' ? 'badge-success' : 'badge-gold'}">
              ${tx.status}
            </span>
          </td>
          <td style="text-align: right;">
            <span class="${isPlus ? 'tx-amount-plus' : 'tx-amount-minus'}">
              ${isPlus ? `+${tx.amount}` : `-${tx.amount}`} CR
            </span>
          </td>
        </tr>
      `;
    }).join('');

    // Update active button state
    ['all', 'earn', 'spend', 'bonus'].forEach(f => {
      const btn = document.getElementById(`tx-filter-${f}`);
      if (btn) {
        if (this.txFilter === f) {
          btn.classList.add('btn-primary');
          btn.classList.remove('btn-secondary');
        } else {
          btn.classList.add('btn-secondary');
          btn.classList.remove('btn-primary');
        }
      }
    });
  }

  filterTransactions(filter) {
    this.txFilter = filter;
    this.renderWallet();
  }

  claimDailyCreditReward() {
    this.currentUser.credits += 5;
    this.transactions.unshift({
      id: `tx-${Date.now().toString().slice(-4)}`,
      type: 'bonus',
      title: 'Daily Swapper Check-In Reward',
      peer: 'SkillsWalk Platform',
      amount: 5,
      date: 'Today',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Granted',
      escrow: false
    });

    this.updateNavProfile();
    this.renderWallet();
    this.triggerConfetti();
    this.showToast('+5 Knowledge Credits added to your wallet!', 'Daily Bonus Claimed');
  }

  // =========================================================================
  // MESSAGING & CHAT SYSTEM
  // =========================================================================
  renderChat() {
    const threadsList = document.getElementById('chat-threads-list');
    const messagesScroll = document.getElementById('chat-messages-scroll');
    const headerUser = document.getElementById('active-chat-header-user');

    if (!threadsList || !messagesScroll) return;

    // Render Threads
    threadsList.innerHTML = this.chatThreads.map(thread => {
      const isActive = thread.userId === this.activeChatUserId;
      const lastMsg = thread.messages[thread.messages.length - 1];
      const previewText = lastMsg ? (lastMsg.sender === 'swap_card' ? 'Swap proposal sent' : lastMsg.text) : '';

      return `
        <div class="chat-thread-item ${isActive ? 'active' : ''}" onclick="app.selectChatThread('${thread.userId}')">
          <div style="position: relative;">
            <img src="${thread.userAvatar}" alt="${thread.userName}" class="thread-avatar">
            ${thread.online ? '<span style="position: absolute; bottom: 0; right: 0; width: 10px; height: 10px; background: #10b981; border: 2px solid var(--bg-primary); border-radius: 50%;"></span>' : ''}
          </div>
          <div class="chat-thread-meta">
            <div class="thread-name">
              <span>${thread.userName}</span>
              <span style="font-size: 0.72rem; color: var(--text-subtle);">${lastMsg ? lastMsg.time : ''}</span>
            </div>
            <div class="thread-last-msg">${previewText}</div>
          </div>
        </div>
      `;
    }).join('');

    // Active Thread Messages
    const activeThread = this.chatThreads.find(t => t.userId === this.activeChatUserId) || this.chatThreads[0];
    if (activeThread && headerUser) {
      headerUser.innerHTML = `
        <img src="${activeThread.userAvatar}" alt="${activeThread.userName}" style="width: 2.8rem; height: 2.8rem; border-radius: 50%; object-fit: cover;">
        <div>
          <div style="font-weight: 800; font-size: 1.05rem;">${activeThread.userName}</div>
          <div style="font-size: 0.78rem; color: #10b981; display: flex; align-items: center; gap: 0.35rem;">
            <span style="width: 6px; height: 6px; background: #10b981; border-radius: 50%;"></span>
            ${activeThread.lastActive}
          </div>
        </div>
      `;

      messagesScroll.innerHTML = activeThread.messages.map(msg => {
        if (msg.sender === 'swap_card') {
          return `
            <div class="inchat-swap-card">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                <span class="badge badge-gold"><i data-feather="repeat"></i> Skill Swap Proposal</span>
                <span style="font-size: 0.75rem; color: var(--text-subtle);">${msg.time}</span>
              </div>
              <div style="font-weight: 700; margin-bottom: 0.25rem;">${msg.offeredSkill} ⇄ ${msg.requestedSkill}</div>
              <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.85rem;">Duration: ${msg.duration}</div>
              <div style="display: flex; gap: 0.5rem;">
                <button class="btn btn-secondary btn-sm" onclick="app.showToast('Proposal details reviewed')">View Details</button>
                <button class="btn btn-primary btn-sm" onclick="app.acceptSwap('${msg.swapId}')">
                  <i data-feather="check"></i> Accept & Confirm
                </button>
              </div>
            </div>
          `;
        }

        const isMe = msg.sender === 'me';
        return `
          <div class="chat-bubble ${isMe ? 'bubble-me' : 'bubble-them'}">
            <div>${msg.text}</div>
            <span class="bubble-time">${msg.time}</span>
          </div>
        `;
      }).join('');

      messagesScroll.scrollTop = messagesScroll.scrollHeight;
    }

    this.initIcons();
  }

  selectChatThread(userId) {
    this.activeChatUserId = userId;
    this.renderChat();
  }

  openChatWithUser(userId) {
    this.activeChatUserId = userId;
    this.navigateTo('chat');
  }

  openProposeSwapModalForActiveChat() {
    const thread = this.chatThreads.find(t => t.userId === this.activeChatUserId);
    if (thread) {
      this.openSwapModal(thread.userId, 'Skill Mentorship');
    }
  }

  sendChatMessage() {
    const input = document.getElementById('chat-msg-input');
    if (!input || !input.value.trim()) return;

    const text = input.value.trim();
    input.value = '';

    const thread = this.chatThreads.find(t => t.userId === this.activeChatUserId);
    if (!thread) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    thread.messages.push({
      sender: 'me',
      text,
      time: timeStr
    });

    this.renderChat();

    // Simulated Auto-Reply from mentor
    setTimeout(() => {
      const responses = [
        "Sounds like a great plan! Looking forward to diving into that.",
        "That works perfectly for my calendar. Let's make sure we have the design sandbox ready.",
        "Awesome! I'll prepare some live examples to walk through during our swap session."
      ];
      const randomResp = responses[Math.floor(Math.random() * responses.length)];

      thread.messages.push({
        sender: 'them',
        text: randomResp,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });

      this.renderChat();
      this.showToast(`New message from ${thread.userName}`, 'Chat Update');
    }, 1200);
  }

  // =========================================================================
  // COMMUNITY & FORUM
  // =========================================================================
  renderCommunity() {
    const container = document.getElementById('community-posts-stream');
    if (!container) return;

    container.innerHTML = this.communityPosts.map(post => {
      return `
        <div class="post-card glass-card">
          <div class="post-header">
            <div class="post-author-box">
              <img src="${post.authorAvatar}" alt="${post.author}" style="width: 3rem; height: 3rem; border-radius: 50%; object-fit: cover;">
              <div>
                <div style="font-weight: 700; font-size: 1rem;">${post.author}</div>
                <div style="font-size: 0.78rem; color: var(--text-muted);">${post.authorRole} • ${post.timestamp}</div>
              </div>
            </div>
            <div style="display: flex; gap: 0.5rem; align-items: center;">
              <span class="badge badge-primary">${post.category}</span>
              <span class="badge badge-cyan">${post.tag}</span>
            </div>
          </div>

          <h3 class="post-title">${post.title}</h3>
          <p class="post-content">${post.content}</p>

          <div class="post-footer">
            <div class="post-actions-group">
              <button class="like-btn ${post.liked ? 'liked' : ''}" onclick="app.togglePostLike('${post.id}')">
                <i data-feather="heart" style="width: 0.95rem; height: 0.95rem; fill: ${post.liked ? 'currentColor' : 'none'};"></i>
                <span>${post.likes}</span>
              </button>
              <button class="like-btn" onclick="app.showToast('Comments thread loaded')">
                <i data-feather="message-circle" style="width: 0.95rem; height: 0.95rem;"></i>
                <span>${post.commentsCount}</span>
              </button>
            </div>

            <div style="display: flex; align-items: center; gap: 0.75rem;">
              ${post.creditsReward ? `
                <span class="badge badge-gold"><i data-feather="dollar-sign"></i> ${post.creditsReward}</span>
              ` : ''}
              <button class="btn btn-primary btn-sm" onclick="app.openSwapModal('user-sarah', '${post.tag}')">
                <i data-feather="repeat"></i> Offer Swap
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    this.initIcons();
  }

  togglePostLike(postId) {
    const post = this.communityPosts.find(p => p.id === postId);
    if (!post) return;

    post.liked = !post.liked;
    post.likes += post.liked ? 1 : -1;
    this.renderCommunity();
  }

  openCreatePostModal() {
    this.openModal('modal-create-post');
  }

  submitNewPost() {
    const cat = document.getElementById('new-post-category').value;
    const title = document.getElementById('new-post-title').value;
    const content = document.getElementById('new-post-content').value;

    if (!title || !content) return;

    this.communityPosts.unshift({
      id: `post-${Date.now()}`,
      author: this.currentUser.name,
      authorAvatar: this.currentUser.avatar,
      authorRole: this.currentUser.role.split('&')[0],
      category: cat,
      tag: 'Knowledge Barter',
      title,
      content,
      likes: 1,
      liked: true,
      commentsCount: 0,
      timestamp: 'Just now',
      creditsReward: '10 cr/hr'
    });

    this.closeModal('modal-create-post');
    this.renderCommunity();
    this.showToast('Your barter post is live in the community feed!', 'Post Published');
  }

  // =========================================================================
  // LEADERBOARD
  // =========================================================================
  renderLeaderboard() {
    const tbody = document.getElementById('leaderboard-table-body');
    if (!tbody) return;

    tbody.innerHTML = LEADERBOARD_USERS.map(u => {
      return `
        <tr>
          <td>
            <strong style="font-size: 1.1rem; ${u.rank === 1 ? 'color: var(--credit-gold);' : ''}">#${u.rank}</strong>
          </td>
          <td>
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <img src="${u.avatar}" alt="${u.name}" style="width: 2.4rem; height: 2.4rem; border-radius: 50%; object-fit: cover;">
              <div>
                <div style="font-weight: 700;">${u.name}</div>
                <div style="font-size: 0.75rem; color: var(--text-subtle);">${u.badge}</div>
              </div>
            </div>
          </td>
          <td><span class="badge badge-primary">${u.primarySkill}</span></td>
          <td><strong>${u.swaps}</strong></td>
          <td>${u.hoursTaught} hrs</td>
          <td style="text-align: right;">
            <strong class="text-gold" style="font-size: 1.1rem;">${u.creditsEarned} CR</strong>
          </td>
        </tr>
      `;
    }).join('');
  }

  // =========================================================================
  // LEARNING PATHS
  // =========================================================================
  renderLearningPaths() {
    const container = document.getElementById('paths-cards-container');
    if (!container) return;

    container.innerHTML = LEARNING_PATHS.map(path => {
      return `
        <div class="path-card glass-card">
          <div class="path-header-row">
            <div>
              <span class="badge badge-primary" style="margin-bottom: 0.4rem;">${path.category}</span>
              <h3 style="font-size: 1.5rem; font-weight: 800;">${path.title}</h3>
              <p style="font-size: 0.95rem; color: var(--text-muted); margin-top: 0.25rem;">${path.description}</p>
            </div>
            <div style="text-align: right;">
              <div class="text-gradient" style="font-family: var(--font-heading); font-size: 2rem; font-weight: 900;">${path.progress}%</div>
              <div style="font-size: 0.75rem; color: var(--text-subtle);">Mastery Level</div>
            </div>
          </div>

          <div class="progress-track">
            <div class="progress-fill" style="width: ${path.progress}%;"></div>
          </div>

          <div class="milestones-grid">
            ${path.milestones.map((m, idx) => `
              <div class="milestone-item ${m.completed ? 'completed' : ''} ${m.activeNow ? 'active-now' : ''}">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  <span style="font-size: 0.75rem; font-weight: 800; color: ${m.completed ? '#34d399' : 'var(--text-subtle)'};">
                    ${m.completed ? '✓ COMPLETED' : `STEP 0${idx + 1}`}
                  </span>
                  ${m.activeNow ? '<span class="badge badge-cyan" style="font-size: 0.65rem;">IN PROGRESS</span>' : ''}
                </div>
                <div style="font-weight: 700; font-size: 0.9rem;">${m.title}</div>
                <div style="font-size: 0.78rem; color: var(--text-muted); margin-top: auto;">
                  Mentor: <strong>${m.mentor}</strong>
                </div>
                ${!m.completed ? `
                  <button class="btn btn-secondary btn-sm" style="margin-top: 0.5rem;" onclick="app.navigateTo('skills')">
                    Book Step Mentor
                  </button>
                ` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      `;
    }).join('');

    this.initIcons();
  }

  // =========================================================================
  // NOTIFICATIONS SYSTEM
  // =========================================================================
  renderNotifications() {
    const list = document.getElementById('notif-items-list');
    const badge = document.getElementById('notif-counter');
    if (!list) return;

    const unreadCount = this.notifications.filter(n => n.unread).length;
    if (badge) {
      badge.textContent = unreadCount;
      badge.style.display = unreadCount > 0 ? 'flex' : 'none';
    }

    list.innerHTML = this.notifications.map(n => `
      <div style="padding: 0.75rem; border-radius: var(--radius-sm); background: ${n.unread ? 'rgba(99, 102, 241, 0.12)' : 'rgba(255, 255, 255, 0.03)'}; border: 1px solid var(--border-glass); cursor: pointer;" onclick="app.handleNotifClick('${n.id}', '${n.link}')">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.2rem;">
          <strong style="font-size: 0.85rem; color: ${n.unread ? 'var(--primary-light)' : 'var(--text-main)'};">${n.title}</strong>
          <span style="font-size: 0.7rem; color: var(--text-subtle);">${n.time}</span>
        </div>
        <p style="font-size: 0.78rem; color: var(--text-muted); margin: 0;">${n.body}</p>
      </div>
    `).join('');
  }

  toggleNotifications() {
    const panel = document.getElementById('notif-dropdown');
    if (panel) {
      panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
  }

  markAllNotifsRead() {
    this.notifications.forEach(n => n.unread = false);
    this.renderNotifications();
    this.showToast('All notifications marked as read');
  }

  handleNotifClick(notifId, link) {
    const n = this.notifications.find(item => item.id === notifId);
    if (n) n.unread = false;
    this.renderNotifications();
    if (link) this.navigateTo(link);
  }

  toggleMobileMenu() {
    const drawer = document.getElementById('mobile-drawer');
    if (drawer) {
      drawer.style.display = drawer.style.display === 'none' ? 'block' : 'none';
    }
  }

  // =========================================================================
  // SWAP PROPOSAL MODAL & ACTIONS
  // =========================================================================
  openSwapModal(peerId, skillName) {
    const peer = this.users.find(u => u.id === peerId) || this.users[1];
    this.activeSwapPeer = peer;

    const modal = document.getElementById('modal-swap-request');
    const avatar = document.getElementById('swap-modal-avatar');
    const name = document.getElementById('swap-modal-mentor-name');
    const role = document.getElementById('swap-modal-mentor-role');
    const skillField = document.getElementById('swap-modal-wanted-skill');

    if (avatar) avatar.src = peer.avatar;
    if (name) name.textContent = peer.name;
    if (role) role.textContent = peer.role;
    if (skillField) skillField.value = skillName || peer.teachSkills[0].name;

    this.openModal('modal-swap-request');
  }

  handleSwapPaymentChange(val) {
    // Optional dynamic calculation
  }

  submitSwapProposal() {
    const peer = this.activeSwapPeer;
    if (!peer) return;

    const wantedSkill = document.getElementById('swap-modal-wanted-skill').value;
    const duration = parseFloat(document.getElementById('swap-modal-duration').value);
    const dateVal = document.getElementById('swap-modal-date').value;
    const notes = document.getElementById('swap-modal-notes').value || 'Looking forward to swapping skills!';

    const creditsCost = Math.round(duration * 10);

    // Create swap request
    const newReq = {
      id: `req-${Date.now().toString().slice(-4)}`,
      fromUser: this.currentUser.id,
      toUser: peer.id,
      offeredSkill: this.currentUser.teachSkills[0].name,
      requestedSkill: wantedSkill,
      status: 'Pending',
      proposedDate: `${dateVal} • 6:00 PM PST`,
      durationHours: duration,
      creditsCost,
      message: notes,
      matchScore: 95
    };

    this.swapRequests.unshift(newReq);

    // Also inject card into chat thread
    let thread = this.chatThreads.find(t => t.userId === peer.id);
    if (!thread) {
      thread = {
        userId: peer.id,
        userName: peer.name,
        userRole: peer.role,
        userAvatar: peer.avatar,
        online: true,
        lastActive: 'Active now',
        messages: []
      };
      this.chatThreads.unshift(thread);
    }

    thread.messages.push({
      sender: 'swap_card',
      swapId: newReq.id,
      status: 'Pending',
      offeredSkill: newReq.offeredSkill,
      requestedSkill: newReq.requestedSkill,
      duration: `${duration} hrs (${creditsCost} Credits)`,
      time: 'Just now'
    });

    this.closeModal('modal-swap-request');
    this.showToast(`Swap request sent to ${peer.name}! Held ${creditsCost} CR in escrow.`, 'Proposal Sent');
    this.renderDashboard();
    this.renderChat();
  }

  acceptSwap(reqId) {
    const req = this.swapRequests.find(r => r.id === reqId);
    if (!req) return;

    req.status = 'Accepted';

    // Add session
    const otherUser = this.users.find(u => u.id === req.fromUser) || this.users[1];
    this.sessions.unshift({
      id: `ses-${Date.now().toString().slice(-4)}`,
      peerId: otherUser.id,
      peerName: otherUser.name,
      peerRole: otherUser.role,
      peerAvatar: otherUser.avatar,
      topic: `${req.requestedSkill} ⇄ ${req.offeredSkill}`,
      scheduledTime: req.proposedDate,
      relativeTime: 'Tomorrow',
      duration: `${req.durationHours * 60} minutes`,
      creditsAmount: req.creditsCost,
      status: 'Confirmed',
      meetingLink: `https://meet.skillswalk.io/room/sw-${Date.now().toString().slice(-4)}`
    });

    this.triggerConfetti();
    this.showToast(`Swap proposal accepted! Session scheduled with ${otherUser.name}.`, 'Swap Confirmed!');
    this.renderDashboard();
    this.renderChat();
  }

  declineSwap(reqId) {
    this.swapRequests = this.swapRequests.filter(r => r.id !== reqId);
    this.showToast('Swap request declined.');
    this.renderDashboard();
  }

  // =========================================================================
  // INTERACTIVE LIVE VIDEO SESSION ROOM & RATING
  // =========================================================================
  launchInteractiveSessionRoom(topic, peerName) {
    const modal = document.getElementById('modal-session-room');
    const timerEl = document.getElementById('session-room-timer');
    
    let secondsLeft = 58 * 60 + 42;
    if (this.sessionTimerInterval) clearInterval(this.sessionTimerInterval);

    this.sessionTimerInterval = setInterval(() => {
      secondsLeft--;
      const m = Math.floor(secondsLeft / 60);
      const s = secondsLeft % 60;
      if (timerEl) {
        timerEl.textContent = `${m}:${s < 10 ? '0' : ''}${s} Remaining`;
      }
    }, 1000);

    this.openModal('modal-session-room');
  }

  finishSessionAndRate() {
    if (this.sessionTimerInterval) clearInterval(this.sessionTimerInterval);
    this.closeModal('modal-session-room');
    this.openModal('modal-rating');
  }

  setStarRating(val) {
    this.selectedStarRating = val;
    const stars = document.querySelectorAll('#star-rating-container .star-icon');
    stars.forEach(star => {
      const starVal = parseInt(star.getAttribute('data-val'), 10);
      if (starVal <= val) {
        star.classList.add('active');
      } else {
        star.classList.remove('active');
      }
    });

    const labels = {
      5: '5.0 — Outstanding Mentor! Highly Recommended',
      4: '4.0 — Great Session! Learned a lot',
      3: '3.0 — Good swap, met expectations',
      2: '2.0 — Needs improvement',
      1: '1.0 — Disappointing'
    };
    document.getElementById('star-rating-label').textContent = labels[val] || '5.0';
  }

  submitRatingReview() {
    const notes = document.getElementById('rating-review-text').value;

    // Release escrow: transfer credits and record transaction
    this.currentUser.hoursLearned += 1.0;
    this.currentUser.credits -= 10;

    this.transactions.unshift({
      id: `tx-${Date.now().toString().slice(-4)}`,
      type: 'spend',
      title: 'Completed Next.js & React 1-on-1 Session (1.0 hr)',
      peer: 'David Kim',
      amount: 10,
      date: 'Today',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Completed',
      escrow: false
    });

    this.closeModal('modal-rating');
    this.triggerConfetti();
    this.updateNavProfile();
    this.renderDashboard();
    this.renderWallet();

    this.showToast('Session verified! 10 Credits transferred to David Kim.', '5-Star Rating Submitted');
  }

  // =========================================================================
  // USER PROFILES MODAL
  // =========================================================================
  openProfileModal(userId) {
    const user = this.users.find(u => u.id === userId) || this.currentUser;
    const container = document.getElementById('profile-modal-content');
    if (!container) return;

    container.innerHTML = `
      <div style="display: flex; align-items: center; gap: 1.25rem; margin-bottom: 1.5rem;">
        <img src="${user.avatar}" alt="${user.name}" style="width: 5rem; height: 5rem; border-radius: 50%; object-fit: cover; border: 3px solid var(--primary-light);">
        <div>
          <h2 style="font-size: 1.6rem; font-weight: 800;">${user.name}</h2>
          <div style="font-size: 0.9rem; color: var(--text-muted);">${user.headline}</div>
          <div style="font-size: 0.8rem; color: var(--text-subtle); margin-top: 0.25rem;">📍 ${user.location} • ★ <strong>${user.rating}</strong> (${user.reviewsCount} reviews)</div>
        </div>
      </div>

      <p style="font-size: 0.95rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">
        ${user.bio}
      </p>

      <div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 1.5rem;">
        ${user.badges.map(b => `
          <div class="badge badge-gold" title="${b.desc}">
            <i data-feather="${b.icon}"></i> ${b.name}
          </div>
        `).join('')}
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
        <div class="glass-card" style="padding: 1rem;">
          <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-subtle); font-weight: 700; margin-bottom: 0.5rem;">Skills I Can Teach:</div>
          <div style="display: flex; flex-direction: column; gap: 0.4rem;">
            ${user.teachSkills.map(ts => `
              <div style="display: flex; justify-content: space-between; font-size: 0.88rem;">
                <span style="font-weight: 600;">${ts.name}</span>
                <span class="text-cyan">${ts.level}</span>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="glass-card" style="padding: 1rem;">
          <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-subtle); font-weight: 700; margin-bottom: 0.5rem;">Skills I Want to Learn:</div>
          <div style="display: flex; flex-direction: column; gap: 0.4rem;">
            ${user.learnSkills.map(ls => `
              <div style="display: flex; justify-content: space-between; font-size: 0.88rem;">
                <span style="font-weight: 600;">${ls.name}</span>
                <span class="badge badge-primary" style="font-size: 0.65rem;">${ls.priority} Priority</span>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <div style="margin-bottom: 1.5rem;">
        <h4 style="font-size: 1rem; font-weight: 700; margin-bottom: 0.75rem;">Verified Peer Reviews</h4>
        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
          ${user.recentReviews.map(r => `
            <div style="padding: 0.85rem; border-radius: var(--radius-sm); background: rgba(10, 11, 20, 0.4); border: 1px solid var(--border-glass);">
              <div style="display: flex; justify-content: space-between; font-size: 0.8rem; margin-bottom: 0.25rem;">
                <strong>${r.author}</strong>
                <span class="text-gold">★ ${r.rating}.0 (${r.skill})</span>
              </div>
              <p style="font-size: 0.82rem; color: var(--text-muted); margin: 0;">"${r.text}"</p>
            </div>
          `).join('')}
        </div>
      </div>

      <div style="display: flex; gap: 0.75rem; justify-content: flex-end;">
        <button class="btn btn-secondary" onclick="app.closeModal('modal-profile')">Close</button>
        ${user.id !== this.currentUser.id ? `
          <button class="btn btn-primary" onclick="app.closeModal('modal-profile'); app.openSwapModal('${user.id}')">
            <i data-feather="repeat"></i> Propose Swap
          </button>
        ` : ''}
      </div>
    `;

    this.openModal('modal-profile');
    this.initIcons();
  }

  // =========================================================================
  // DEMO PERSONA SWITCHER & ONBOARDING
  // =========================================================================
  openAuthModal(mode) {
    this.openModal('modal-auth');
  }

  switchPersona(userId) {
    const target = this.users.find(u => u.id === userId);
    if (!target) return;

    this.currentUser = JSON.parse(JSON.stringify(target));
    this.closeModal('modal-auth');
    this.renderAll();
    this.showToast(`Logged in as ${this.currentUser.name} (${this.currentUser.role})`, 'Persona Switched');
  }

  handleSignUpSubmit() {
    const name = document.getElementById('signup-name').value;
    const teach = document.getElementById('signup-teach').value;
    const learn = document.getElementById('signup-learn').value;

    const newUser = {
      id: `user-${Date.now().toString().slice(-4)}`,
      name,
      role: `${teach} Specialist`,
      headline: `Teaching ${teach} | Eager to learn ${learn}`,
      avatar: 'assets/avatar_alex.jpg',
      location: 'New Swapper (Local)',
      rating: 5.0,
      reviewsCount: 0,
      credits: 20, // +20 Welcome bonus
      hoursTaught: 0,
      hoursLearned: 0,
      bio: `Hello! I just joined SkillsWalk to trade ${teach} skills in exchange for learning ${learn}.`,
      badges: [{ id: 'b0', name: 'Skill Explorer', icon: 'compass', desc: 'New Barterer' }],
      teachSkills: [{ name: teach, level: 'Intermediate', rate: 10, hours: 0, tags: [teach] }],
      learnSkills: [{ name: learn, priority: 'High', currentLevel: 'Beginner', target: `Master ${learn}` }],
      recentReviews: []
    };

    this.users.push(newUser);
    this.currentUser = newUser;
    this.transactions.unshift({
      id: `tx-${Date.now().toString().slice(-4)}`,
      type: 'bonus',
      title: 'SkillsWalk 20 Credits Welcome Grant',
      peer: 'Platform Welcome Bonus',
      amount: 20,
      date: 'Today',
      time: 'Just now',
      status: 'Granted',
      escrow: false
    });

    this.closeModal('modal-auth');
    this.renderAll();
    this.triggerConfetti();
    this.showToast(`Welcome ${name}! +20 Credits added to your wallet!`, 'Account Created');
  }

  // =========================================================================
  // MODAL UTILITIES
  // =========================================================================
  openModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) {
      m.classList.add('open');
      this.initIcons();
    }
  }

  closeModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.remove('open');
  }

  // =========================================================================
  // TOAST NOTIFICATIONS & CONFETTI
  // =========================================================================
  showToast(message, title = 'Notification', type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
      <div style="background: rgba(99, 102, 241, 0.2); padding: 0.4rem; border-radius: 50%; color: var(--primary-light);">
        <i data-feather="bell" style="width: 1.1rem; height: 1.1rem;"></i>
      </div>
      <div style="flex: 1;">
        <div style="font-weight: 700; font-size: 0.9rem; margin-bottom: 0.15rem;">${title}</div>
        <div style="font-size: 0.8rem; color: var(--text-muted);">${message}</div>
      </div>
    `;

    container.appendChild(toast);
    this.initIcons();

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(40px)';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  triggerConfetti() {
    if (window.confetti) {
      window.confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#a855f7', '#f59e0b', '#06b6d4', '#10b981']
      });
    }
  }

  // =========================================================================
  // INTERACTIVE BARTER CALCULATOR
  // =========================================================================
  updateCalculator(hours) {
    const h = parseInt(hours, 10);
    const hoursDisp = document.getElementById('calc-hours-display');
    const creditsVal = document.getElementById('calc-credits-val');
    const learnVal = document.getElementById('calc-learn-val');
    const savedVal = document.getElementById('calc-saved-val');

    if (hoursDisp) hoursDisp.textContent = `${h} ${h === 1 ? 'Hour' : 'Hours'} / week`;
    if (creditsVal) creditsVal.textContent = `+${h * 10} CR`;
    if (learnVal) learnVal.textContent = `${h}.0 Hrs`;
    if (savedVal) savedVal.textContent = `$${(h * 50 * 52).toLocaleString()}`;
  }
}

// Global Application Instance
let app;
document.addEventListener('DOMContentLoaded', () => {
  app = new SkillsWalkApp();
});
